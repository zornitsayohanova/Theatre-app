This DEMO font is not contain all of its unicode glyphs, and for PERSONAL USE ONLY.

Get the FULL VERSION and COMMERCIAL LICENSE here:

https://crmrkt.com/NJEKyd?u=craftsupplyco 

Paypal account for donation : https://paypal.me/nazzars
 
Happy Crafting

Thanks.

Craft Supply Co